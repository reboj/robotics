function  retreat(position,sawyer)
%RETREAT Summary of this function goes here
%   Detailed explanation goes here
 
%TEST
% position =  transl([-1.4, -0.4, 1])*troty(pi/2); 

pause(10);

t = 5;                                                                      % Total time (s)
deltaT = 0.1;                                                               % Control frequency
steps = t/deltaT;

display('Collision Detected!')




for i = 1:steps
    q_current = sawyer.model.ikcon(position);
    J = sawyer.model.jacob0(q_current);
    desired_V = [0 -0.5 0  0  0.5  0 ]';
    q_dot     = pinv(J) * desired_V;
    q_k   = q_current + (q_dot*deltaT)';
    sawyer.model.animate(q_k);
    drawnow(); 
    position = sawyer.model.fkine(q_k);
 end
end

