classdef Coordinates
    %COORDINATES class store coordinates.

    
    properties
f_hdmi1 = [-0.95, -0.4, 1.115]; 
f_h1E   = [-1, -0.4, 1.115];
f_hdmi2 = [-0.95, -0.5, 1.115];
f_h2E   = [-1, -0.5, 1.115];
m_hdmi  = [-1.875, 0.05, 1.16];
f_h3E   = [-1.05, -0.4, 1.115];


    0.0441    0.9990   -0.0008   -2.0373
    0.0883   -0.0031    0.9961    0.5146
    0.9951   -0.0440   -0.0884    1.3460
         0         0         0    1.0000
    end
    
    methods
        function self = Coordinates()

            
        end
    end
end

