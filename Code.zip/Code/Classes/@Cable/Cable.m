classdef Cable
    %CABLE class stores simulated mesh vertices of cable objects.
    %Functions used here are to "grab" object in MATLAB.
    %Functions used here are directly influenced from
    %"PuttingSimulatedObjectsIntoTheEnvironment.m" from UTS ROBOTICS SUBJ.
    
    properties
        f;
        v;
        data;
        vertexCount;
        objVerts;
        objPose;                                                                    % 4x4 Matrix
        vertexColours;
        objMesh_h;
        updatedPoints;
        
        
    end
    
    methods
        function self = Cable(plyfile,coord)
            
        [f,v,data] = plyread(plyfile,'tri');     
        vertexCount = size(v,1);
        midPoint = sum(v)/vertexCount; 
        objVerts = v - repmat(midPoint,vertexCount,1);
        
        objPose = makehgtform('translate',coord);;  
        
        vertexColours = [data.vertex.red, data.vertex.green, data.vertex.blue] / 255;
        
        objMesh_h = trisurf(f,objVerts(:,1),objVerts(:,2), objVerts(:,3) ...
         ,'FaceVertexCData',vertexColours,'EdgeColor','interp','EdgeLighting','flat'); 
     
        updatedPoints = [objPose * [objVerts,ones(vertexCount,1)]']';
        
        objMesh_h.Vertices = updatedPoints(:,1:3);
        drawnow(); 
        
        self.f = f;
        self.v = v;
        self.data= data;
        self.vertexCount = vertexCount;
        self.objVerts = objVerts;
        self.objPose = objPose;                                                                    % 4x4 Matrix
        self.vertexColours = vertexColours;
        self.objMesh_h = objMesh_h;
        self.updatedPoints = updatedPoints;
        
        end
        
        
        
        function  move(self,newPose)
            %Move function summary: updates obj verticies then plot. 
            
        
            
        self.updatedPoints = [newPose * [self.objVerts,ones(self.vertexCount,1)]']';
        self.objMesh_h.Vertices = self.updatedPoints(:,1:3);
        drawnow();   

        end
    end
end

