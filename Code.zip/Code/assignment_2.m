function assignment_2()

close all;
clc;
set(0,'DefaultFigureWindowStyle','docked')
%% SAWYER INTIALIZATION AND PLOT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sawyer = SAWYER;
baseOrigin = [-1.875, -0.6, 1.06];
sawyer.model.base = transl(baseOrigin); 
hold on; 

%% PLOT ENVIRONMENT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% COORDINATES
% coord = Coordinates();
hdmi_m1 = Cable('HDMIMalegreen.ply',[-2.037,0.5146,1.3460]);
hdmi_m2 = Cable('HDMIMalegreen.ply',[-2.037,0.5146,1.3460]);
loadEnvironment();
view([150 20])
%% Robotic Movement using RMRC  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

movement(sawyer,hdmi_m1,hdmi_m2,0,0,0,0);                                          
movement(sawyer,hdmi_m1,hdmi_m2,0,0,1,0); 
movement(sawyer,hdmi_m1,hdmi_m2,0,0,0,1); 




end